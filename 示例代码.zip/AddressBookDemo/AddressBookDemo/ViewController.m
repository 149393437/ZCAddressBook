//
//  ViewController.m
//  AddressBookDemo
//
//  Created by zhangcheng on 16/2/25.
//  Copyright © 2016年 zhangcheng. All rights reserved.
//

#import "ViewController.h"
#import "ZCAddressBook.h"

//iOS9通讯录库
#import <Contacts/Contacts.h>
//iOS9带UI的库
#import <ContactsUI/ContactsUI.h>
@interface ViewController ()<UITableViewDataSource,UITableViewDelegate,CNContactPickerDelegate>
{

}
@property(nonatomic,strong)NSMutableDictionary*dataDic;
@property(nonatomic,strong)NSArray*dataArray;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)addressClick:(id)sender {
    
    //添加联系人
    ZCAddressBook*address=[ZCAddressBook shareControl];
    

    NSArray*titleArray=@[@"大娃",@"二娃",@"三娃",@"四娃",@"五娃",@"七娃"];
    
    for (NSString*str in titleArray) {
        //判断这个人是否已经存在
        
        [address addContactName:str phoneNum:[NSString stringWithFormat:@"%d",arc4random()%100000000] withLabel:@"动漫人物"];
    }
    
    
    
}
//自定义联系人,只获取数据源
- (IBAction)customAddressList:(id)sender {
    //获取数据源
    NSDictionary*dic=[[ZCAddressBook shareControl]getPersonInfo];
    self.dataDic=[NSMutableDictionary dictionaryWithDictionary:dic];
    NSLog(@"%@",dic);
    
    //排序后的key值
    NSArray*array=[[ZCAddressBook shareControl]sortMethod];
    self.dataArray=[NSMutableArray arrayWithArray:array];
    NSLog(@"%@",array);
    
    
    [self createTableView];
    
    
}
-(void)createTableView{
    //查询一下tag值为100的
    UITableView*tableView=[self.view viewWithTag:100];
    
    if (tableView) {
        return;
    }
    
    tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 100, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-100) style:UITableViewStylePlain];
    tableView.tag=100;
    tableView.delegate=self;
    tableView.dataSource=self;
    [self.view addSubview:tableView];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
   return self.dataArray.count;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.dataDic[self.dataArray[section]] count];
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"ID"];
    }
    
    NSDictionary*dic=self.dataDic[self.dataArray[indexPath.section]][indexPath.row];
    
    cell.textLabel.text=[NSString stringWithFormat:@"%@%@",dic[@"first"],dic[@"last"]];
    
    cell.detailTextLabel.text=[dic[@"telphone"]firstObject];
    
    
    
    return cell;
    
}
//获取系统通讯录
- (IBAction)systemAddressClick:(id)sender {
    
    [[ZCAddressBook shareControl]showPhoneViewWithTarget:self Block:^(BOOL isSuccess, NSDictionary *dic) {
        NSLog(@"~~~%@",dic);
    }];
    
    
}
- (IBAction)sendMessage:(id)sender {
    //发送短信,群发，可以有指定内容
    [[ZCAddressBook shareControl]showSystemMessageToListArray:@[@"13811928431"] Message:[NSString stringWithFormat:@"%@正在使用你的库文件",[[UIDevice currentDevice] systemName]] ViewController:self Block:^(int a) {
        NSLog(@"%d",a);
    }];
  
}
- (IBAction)iOS9AddressClick:(id)sender {
    //以下方法已经加入封装库中,会自动判断
    //添加的联系人
    CNMutableContact*contact=[[CNMutableContact alloc]init];
    contact.familyName=@"iOS9姓氏";
    contact.givenName=@"iOS9名字";
    contact.phoneNumbers=@[[CNLabeledValue labeledValueWithLabel:CNLabelPhoneNumberiPhone value:[CNPhoneNumber phoneNumberWithStringValue:@"12323123"]]];
    
    //设置一个请求
    CNSaveRequest*request=[[CNSaveRequest alloc]init];
    //添加这个联系人
    [request addContact:contact toContainerWithIdentifier:nil];
    //联系人写入
    CNContactStore*store=[[CNContactStore alloc]init];
    [store executeSaveRequest:request error:nil];
    
    
}
- (IBAction)iOS9CustomAddressClick:(id)sender {
    //以下方法已经加入封装库中,会自动判断

    CNContactStore*store=[[CNContactStore alloc]init];
    //检索的数据
    CNContactFetchRequest*fetch=[[CNContactFetchRequest alloc]initWithKeysToFetch:@[CNContactFamilyNameKey,CNContactGivenNameKey,CNContactPhoneNumbersKey]];

    [store enumerateContactsWithFetchRequest:fetch error:nil usingBlock:^(CNContact * _Nonnull contact, BOOL * _Nonnull stop) {
        //需要注意搜索条件里面需要带3个key才可以,读取电话号码时候用以下方法
        //[[[contact.phoneNumbers firstObject]value]stringValue]
        
        NSLog(@"%@~%@~%@",contact.familyName,contact.givenName,[[[contact.phoneNumbers firstObject]value]stringValue]);
        
    }];
    
    
    
    
    
}
- (IBAction)iOS9SystemAddressClick:(id)sender {
    //以下方法已经加入封装库中,会自动判断

    CNContactPickerViewController*vc=[[CNContactPickerViewController alloc]init];
    vc.delegate=self;
    [self presentViewController:vc animated:YES completion:nil];

}
-(void)contactPicker:(CNContactPickerViewController *)picker didSelectContact:(CNContact *)contact
{
    NSLog(@"%@~~%@",contact.familyName,contact.givenName);

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
