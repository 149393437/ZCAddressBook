//
//  MainViewController.h
//  通讯录Demo
//
//  Created by ZhangCheng on 14-4-7.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AddressBookUI/AddressBookUI.h>
@interface MainViewController : UIViewController<ABPeoplePickerNavigationControllerDelegate>

@end
