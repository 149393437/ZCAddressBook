//
//  AppDelegate.h
//  通讯录Demo
//
//  Created by ZhangCheng on 14-4-7.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
